#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "Usage: $0 <recording.jfr> [output-dir]" >&2
  exit 2
}

[[ $# -ge 1 && $# -le 2 ]] || usage
JFR_FILE=$1
[[ -f "$JFR_FILE" ]] || { echo "JFR file not found: $JFR_FILE" >&2; exit 1; }
command -v jfr >/dev/null 2>&1 || { echo "'jfr' not found. Use a JDK installation, not a JRE-only runtime." >&2; exit 1; }

if [[ $# -eq 2 ]]; then
  OUT=$2
else
  base=$(basename "$JFR_FILE" .jfr)
  OUT="./${base}-jfr-analysis"
fi
mkdir -p "$OUT/views" "$OUT/raw"

JFR_VERSION=$(jfr --version 2>&1 | head -1 || true)
printf '%s\n' "$JFR_VERSION" > "$OUT/jfr-tool-version.txt"

# Core metadata. These work on older JDKs as well.
jfr summary "$JFR_FILE" > "$OUT/summary.txt"
jfr metadata "$JFR_FILE" > "$OUT/metadata.txt"

HAS_VIEW=false
if jfr help view >/dev/null 2>&1; then
  HAS_VIEW=true
fi
printf '%s\n' "$HAS_VIEW" > "$OUT/has-view.txt"

# Extract event type names/counts from summary in a simple searchable form.
# Keep the original summary as the source of truth because formatting differs by JDK.
awk '
  BEGIN { in_events=0 }
  /^ Event Type/ { in_events=1; next }
  in_events && /^[[:space:]]*$/ { next }
  in_events && $1 ~ /^[[:alnum:]_.\-$]+$/ && $2 ~ /^[0-9]+$/ { print $1 "\t" $2 }
' "$OUT/summary.txt" > "$OUT/event-counts.tsv" || true

# Best-effort list of custom/non-JDK event types.
awk -F '\t' '
  $1 !~ /^(jdk\.|java\.|javax\.|sun\.|com\.oracle\.)/ && NF >= 2 { print }
' "$OUT/event-counts.tsv" > "$OUT/custom-event-counts.tsv" || true

if $HAS_VIEW; then
  jfr view types "$JFR_FILE" > "$OUT/event-types.txt" 2>&1 || true

  VIEWS=(
    recording
    system-information
    jvm-flags
    active-settings
    cpu-information
    cpu-load
    cpu-load-samples
    thread-cpu-load
    hot-methods
    native-methods
    gc-configuration
    heap-configuration
    gc
    gc-cpu-time
    gc-pauses
    gc-pause-phases
    gc-concurrent-phases
    safepoints
    allocation-by-site
    allocation-by-class
    allocation-by-thread
    thread-allocation
    object-statistics
    memory-leaks-by-site
    memory-leaks-by-class
    contention-by-site
    contention-by-class
    contention-by-thread
    exception-count
    exception-by-site
    exception-by-message
    file-reads-by-path
    file-writes-by-path
    socket-reads-by-host
    socket-writes-by-host
    network-utilization
    thread-count
    pinned-threads
    deoptimizations-by-site
    deoptimizations-by-reason
    longest-compilations
    compiler-statistics
    compiler-phases
    vm-operations
    events-by-name
    events-by-count
  )

  for view in "${VIEWS[@]}"; do
    out="$OUT/views/${view}.txt"
    if ! jfr view --width 200 --cell-height 12 "$view" "$JFR_FILE" > "$out" 2>&1; then
      rm -f "$out"
    fi
  done
else
  # JDK 17 fallback: extract focused raw events. Some event types may not be present.
  # jfr print accepts comma-separated event filters and simply emits matching events.
  # Keep this compatible with macOS Bash 3.2 (no associative arrays).
  while IFS='|' read -r group events; do
    [[ -n "$group" ]] || continue
    jfr print --stack-depth 64 --events "$events" "$JFR_FILE" > "$OUT/raw/${group}.txt" 2>&1 || true
  done <<'GROUPS'
cpu|jdk.CPULoad,jdk.ExecutionSample,jdk.NativeMethodSample,jdk.ThreadCPULoad
gc|jdk.GarbageCollection,jdk.GCPhasePause,jdk.GCHeapSummary,jdk.G1HeapSummary,jdk.PSHeapSummary,jdk.ParallelOldGarbageCollection
allocation|jdk.ObjectAllocationSample,jdk.ObjectAllocationInNewTLAB,jdk.ObjectAllocationOutsideTLAB,jdk.ThreadAllocationStatistics,jdk.OldObjectSample
contention|jdk.JavaMonitorEnter,jdk.JavaMonitorWait,jdk.ThreadPark
exceptions|jdk.JavaExceptionThrow,jdk.ExceptionStatistics
io|jdk.FileRead,jdk.FileWrite,jdk.SocketRead,jdk.SocketWrite
jit|jdk.Compilation,jdk.CompilerPhase,jdk.Deoptimization,jdk.CodeCacheStatistics
threads|jdk.ThreadStart,jdk.ThreadEnd,jdk.JavaThreadStatistics
GROUPS
fi

# Build a small navigation file for the agent/human.
{
  echo "# JFR analysis index"
  echo
  echo "- Recording: \`$JFR_FILE\`"
  echo "- jfr tool: \`$JFR_VERSION\`"
  echo "- Aggregated views available: \`$HAS_VIEW\`"
  echo
  echo "## Core files"
  echo "- \`summary.txt\`: event counts and recording summary"
  echo "- \`metadata.txt\`: event schemas and recording metadata"
  echo "- \`event-counts.tsv\`: best-effort event count table"
  echo "- \`custom-event-counts.tsv\`: best-effort non-JDK event list"
  if $HAS_VIEW; then
    echo "- \`event-types.txt\`: event types present in the recording"
    echo
    echo "## Generated views"
    for f in "$OUT"/views/*.txt; do
      [[ -e "$f" ]] || continue
      basename "$f"
    done | sort | sed 's/^/- `views\//; s/$/`/'
  else
    echo
    echo "## JDK 17 fallback extracts"
    for f in "$OUT"/raw/*.txt; do
      [[ -e "$f" ]] || continue
      basename "$f"
    done | sort | sed 's/^/- `raw\//; s/$/`/'
  fi
} > "$OUT/INDEX.md"

echo "$OUT"
