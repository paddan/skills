#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat >&2 <<'USAGE'
Usage: ./install.sh [--codex|--claude|--opencode|--all] [--copy]

Default: --all using symlinks.
--copy copies the skill instead of creating symlinks.
USAGE
  exit 2
}

TARGET=all
MODE=link
for arg in "$@"; do
  case "$arg" in
    --codex) TARGET=codex ;;
    --claude) TARGET=claude ;;
    --opencode) TARGET=opencode ;;
    --all) TARGET=all ;;
    --copy) MODE=copy ;;
    *) usage ;;
  esac
done

SRC=$(cd "$(dirname "$0")" && pwd)
NAME=jfr-analyzer

install_one() {
  local base=$1
  local dest="$base/$NAME"
  mkdir -p "$base"
  rm -rf "$dest"
  if [[ "$MODE" == copy ]]; then
    cp -R "$SRC" "$dest"
    rm -f "$dest/install.sh"
  else
    ln -s "$SRC" "$dest"
  fi
  echo "Installed: $dest"
}

case "$TARGET" in
  codex)
    install_one "$HOME/.agents/skills"
    ;;
  claude)
    install_one "$HOME/.claude/skills"
    ;;
  opencode)
    install_one "$HOME/.config/opencode/skills"
    ;;
  all)
    # ~/.agents/skills is shared by Codex and OpenCode. Claude requires ~/.claude/skills.
    install_one "$HOME/.agents/skills"
    install_one "$HOME/.claude/skills"
    ;;
esac
